package com.gavs.springbootLessons.controller;

import java.util.Scanner;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.gavs.springbootLessons.model.Employee;
import com.gavs.springbootLessons.model.EmployeeDAO;
@RestController
public class EmployeeService {
	Scanner sc = new Scanner(System.in);
	EmployeeDAO e = new EmployeeDAO();
	@RequestMapping("/hello")
    public String welcomepage() {
        return "hello to Spring REST Controller";
    }
    @RequestMapping(value="/findEmployee",method= RequestMethod.GET)
    public Employee homepage(@RequestBody Employee emp1) {
        Employee emp = new Employee();
        int emp_id=emp1.getId();
        emp=e.findEmployeeById(emp_id);
        return emp;
    }
    @RequestMapping(value="/addEmployee",method= RequestMethod.POST)
    public int addEmployee(@RequestBody Employee emp1) {
    	int emp_id=emp1.getId();
    	String emp_name=emp1.getName();
    	int i=e.AddEmployee(emp_id, emp_name);
    	if(i==1) {
    		System.out.println("Employee details added");
    	}
    	else {
    		System.out.println("There is already an employee in the id you mentioned below ");
    	}
        return 0;
    }
    @RequestMapping(value="/updateEmployee",method= RequestMethod.PUT)
    public int modifyEmployee(@RequestBody Employee emp1) {
    	int emp_id=emp1.getId();
    	String emp_name=emp1.getName();
    	int i=e.UpdateBook(emp_id, emp_name);
    	if(i==1) {
    		System.out.println("Employee details updated");
    	}
    	else {
    		System.out.println("There is no employee in the id you mentioned below ");
    	}
        return 0;
    }
    @RequestMapping(value="/removeEmployee",method= RequestMethod.DELETE)
    public int removeEmployee(@RequestBody Employee emp1) {
    	int emp_id=emp1.getId();
    	int i=e.deleteEmployee(emp_id);
    	if(i==1) {
    		System.out.println("Employee deleted");
    	}
    	else {
    		System.out.println("There is no employee in the id you mentioned below ");
    	}
        return 0;
    }
}
