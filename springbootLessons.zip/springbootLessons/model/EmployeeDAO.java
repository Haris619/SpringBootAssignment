package com.gavs.springbootLessons.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class EmployeeDAO {
	
		public static Connection getcon() {
			Connection con =null;
	        String strUserName="root";
	        String strPassword="admin";
	        try
	        {
	            java.util.Properties p = new java.util.Properties();
	            p.put("user",strUserName);
	            p.put("password",strPassword);
	            String driverName="com.mysql.cj.jdbc.Driver";
	            Class.forName(driverName);
	            String url="jdbc:mysql://localhost:3306/spring";
	            con= DriverManager.getConnection(url,p);
	            
	         }catch (SQLException sqe)
	         {
	            System.out.println("SQLException:  " + sqe.getMessage());
	         }catch (Exception e2)
	         {
	            System.out.println("Exception:  " + e2.getMessage());
	         }
			return con;
		}
		
		public boolean checkId(int id) {
			boolean flag=false;
	    	try {
	    		Connection con = getcon();
	    		int number=0;
				PreparedStatement stmt=con.prepareStatement("select Emp_id from new_table where Emp_id=?");  
		        stmt.setInt(1, id);
		    	ResultSet rs=stmt.executeQuery();
		    	while(rs.next()) {
		    		number =(rs.getInt(1));
		    	}
		    	if(number==(id)) {
		        		flag= true;
		        }
	    	}
		    	catch (SQLException sqe)
		        {
		           System.out.println("SQLException:  " + sqe.getMessage());
		        }catch (Exception e2)
		        {
		           System.out.println("Exception:  " + e2.getMessage());
		        }
	    	return flag;
		}
		
		public int AddEmployee(int id, String emp_name) {
			Connection con = getcon();
			int i=0;
			boolean flag=checkId(id);
			try {
				if(flag==false) {
					PreparedStatement insert=con.prepareStatement("insert into new_table (Emp_id,Emp_name) values(?,?)");	    	
		    		insert.setInt(1, id);
		    		insert.setString(2, emp_name);
		    		insert.executeUpdate();
		    		i=1;
				}
				else {
					i=0;
				}
	    	}
	    	catch (SQLException sqe)
	        {
	           System.out.println("SQLException:  " + sqe.getMessage());
	           i=0;
	        }catch (Exception e2)
	        {
	           System.out.println("Exception:  " + e2.getMessage());
	           i=0;
	        }
			return i;
		}
		public int deleteEmployee(int id) {
			Connection con = getcon();
			int i=1;
			try {
			boolean flag = checkId(id);
		    	if(flag==true) {
		    		PreparedStatement delt=con.prepareStatement("delete from new_table where Emp_id=?");
		    		delt.setInt(1, id);
		    		delt.executeUpdate();
		    	}
		    	else {
		    		i=0;
		    	}
	    	}
	    	catch (SQLException sqe)
	        {
	           System.out.println("SQLException:  " + sqe.getMessage());
	        }catch (Exception e2)
	        {
	           System.out.println("Exception:  " + e2.getMessage());
	        }
			return i;
		}
		public int UpdateBook(int id,String name) {
			Connection con = getcon();
			int i=1;
			try {
			boolean flag = checkId(id);
		    	if(flag==true) {
		    		PreparedStatement update=con.prepareStatement("update new_table set Emp_name=? where Emp_id=?");	    	
		    		update.setString(1, name);
		    		update.setInt(2, id);
		    		update.executeUpdate();
		    	}
		    	else {
		    		i=0;
		    	}
	    	}
	    	catch (SQLException sqe)
	        {
	           System.out.println("SQLException:  " + sqe.getMessage());
	        }catch (Exception e2)
	        {
	           System.out.println("Exception:  " + e2.getMessage());
	        }
			return i;
		}

		public Employee findEmployeeById(int id) {
			
			Employee emp = new Employee();
			
			try {
				Connection con = getcon();
				boolean flag = checkId(id);
		    	if(flag==true) {
		    		PreparedStatement show=con.prepareStatement("select * from new_table where Emp_id=?");
		    		show.setInt(1, id);
		    		ResultSet rs=show.executeQuery();
		    		rs.next();
		    		emp.setId(rs.getInt(1));
		    		emp.setName(rs.getString(2));
		    		}
			}
		    	catch (SQLException sqe)
		        {
		           System.out.println("SQLException:  " + sqe.getMessage());
		        }catch (Exception e2)
		        {
		           System.out.println("Exception:  " + e2.getMessage());
		        }
			return emp;
		}
			
}